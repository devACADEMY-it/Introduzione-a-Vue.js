Vue.component('todos-title', {
  props: ['title'],
  template: `
      <h1>{{ title }}</h1>
  `
});

const vm = new Vue({
  el: '#app',
  data: {
    title: 'todos',
    currentTodo:'',
    completedTodos: [],
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    }],
  },
  methods: {
    handleKeyup(event) {
        const currentTodoToInsert = this.currentTodo;

        if(currentTodoToInsert) {
          this.todos.push({title: currentTodoToInsert});
          this.currentTodo = '';
        }

    },
    deleteTodo(todoIndex) {
      this.todos.splice(todoIndex, 1);
    }
  },
  computed: {
    isTodosEmpty() {
      return this.todos.length === 0;
    }
  },
  watch: {
    async currentTodo(newValue) {
      console.log(newValue);
      await localforage.setItem('todoapp-partialtodo', newValue);
      console.log("Todo memorizzato");
    }
  },
  async created() {
    console.log("The instance was created!")
    const prevTodo = await localforage.getItem('todoapp-partialtodo') || '';
    console.log(prevTodo);
    this.currentTodo = prevTodo;
  },
  mounted() {
    console.log("The instance was inserted into the DOM!")
  },
  updated() {
    console.log("The instance was updated!")
  },
  template: `
    <section class="todoapp">
        <header class="header">
            <todos-title :title="title"></todos-title>
            <input
              v-model.trim="currentTodo"
              @keyup.enter="handleKeyup"
              id="input-todo"
              class="new-todo"
              autofocus
              autocomplete="off"
              placeholder="What needs to be done?">
        </header>
        <section class="main">
            <ul class="todo-list">
                <li class="todo" v-if="isTodosEmpty">
                    <div class="view">
                        <label>Nothing to show here</label>
                    </div>
                </li>
                <template v-else>
                  <li
                  v-for="({title}, i) in todos"
                  class="todo"
                  :class="{completed: completedTodos.includes(i)}"
                  :key="i">
                      <div class="view">
                          <input class="toggle" v-model="completedTodos" :value="i"
                          type="checkbox">
                          <label>{{title}}</label>
                          <button class="destroy" @click="deleteTodo(i)"></button>
                      </div>
                  </li>
                </template>
            </ul>
        </section>
    </section>
  `
});