const vm = new Vue({
  el: '#app',
  data: {
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    },{
      title:"Lavare i piatti!"
    }],
  },
  methods: {
    handleEvent(event) {
      const currInput = event.target.value;
      console.log(currInput);
    }
  },
  created() {
    console.log("The instance was created!")
  },
  mounted() {
    console.log("The instance was inserted into the DOM!")
  },
  updated() {
    console.log("The instance was updated!")
  },
  template: `
    <section class="todoapp">
        <header class="header">
            <h1>todos</h1>
            <input
              @input="handleEvent"
              class="new-todo"
              autofocus
              autocomplete="off"
              placeholder="What needs to be done?">
        </header>
        <section class="main">
            <ul class="todo-list">
                <li class="todo" v-if="todos.length === 0">
                    <div class="view">
                        <label>Nothing to show here</label>
                    </div>
                </li>
                <template v-else>
                  <li v-for="({title}, i) in todos" class="todo" :key="i">
                      <div class="view">
                          <input class="toggle" type="checkbox">
                          <label>{{title}}</label>
                          <button class="destroy"></button>
                      </div>
                  </li>
                </template>
            </ul>
        </section>
    </section>
  `
});