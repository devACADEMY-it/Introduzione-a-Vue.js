new Vue({
  el: '.todoapp',
  data: {
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    }],
  }
});