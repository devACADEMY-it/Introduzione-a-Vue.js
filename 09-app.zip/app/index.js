const vm = new Vue({
  el: '.todoapp',
  data: {
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    }],
  },
  methods: {
    handleEvent(event) {
      console.log(event.target.value);
    }
  },
  created() {
    console.log("The instance was created!")
  },
  mounted() {
    console.log("The instance was inserted into the DOM!")
  },
  updated() {
    console.log("The instance was updated!")
  },
});