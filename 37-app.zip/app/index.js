Vue.component('todos-title', {
  props: ['title'],
  template: `
      <h1>{{ title }}</h1>
  `
});

Vue.component('todo-item', {
  props:['index', 'title', 'isCompleted'],
  template: `
    <li
    class="todo"
    :class="{completed: isCompleted}">
      <div class="view">
        <input class="toggle" @change="$emit('complete-todo', index)"
        :checked="isCompleted"
        type="checkbox">
          <label>{{title}}</label>
          <button class="destroy" @click="$emit('delete-todo', index)"></button>
      </div>
    </li>
  `
})

Vue.component('todos-list', {
  props: ['todos', 'completedTodos'],
  computed: {
    isTodosEmpty() {
      console.log(this.todos)
      return this.todos.length === 0;
    }
  },
  template: `
    <ul class="todo-list">
      <slot v-if="isTodosEmpty">
        <li class="todo">
          <div class="view">
            <label>Nothing to show here</label>
          </div>
        </li>
      </slot>
      <template v-else>
        <todo-item
        v-for="({title, id}) in todos"
        :index="id"
        :title="title"
        :isCompleted="completedTodos.includes(id)"
        :key="id"
        @delete-todo="id => $emit('delete-todo', id)"
        @complete-todo="id => $emit('complete-todo', id)"
        >
        </todo-item>
      </template>
    </ul>
  `
});

Vue.component('todo-input', {
  props: ['value'],
  template: `
    <input :value="value" @input="$emit('input', $event.target.value)"
    @keyup.enter="$emit('keyup')"
    class="new-todo"
    autofocus
    autocomplete="off"
    placeholder="What needs to be done?">
  `
});

const vm = new Vue({
  el: '#app',
  data: {
    title: 'todos',
    currentTodo:'',
    completedTodos: [],
    todos: [{
      title:"Shopping!",
      id: 1,
    },{
      title:"Video Corso",
      id: 2,
    },{
      title:"Lavare i piatti",
      id: 3,
    }],
  },
  methods: {
    handleKeyup(event) {
        const currentTodoToInsert = this.currentTodo;

        if(currentTodoToInsert) {
          this.todos.push({
            title: currentTodoToInsert,
            id: Math.ceil(Math.random() * 12345678) + 3}
          );
          this.currentTodo = '';
        }
    },
    deleteTodo(todoId) {
      this.todos.splice(this.todos.findIndex(({id}) => id === todoId), 1);
      this.completedTodos = this.completedTodos.filter(id => id !== todoId);
    },
    handleCompleteTodo(todoId) {
      if(this.completedTodos.includes(todoId)) {
        this.completedTodos = this.completedTodos.filter(id => id !== todoId);
      } else {
        this.completedTodos.push(todoId);
      }
    }
  },
  watch: {
    async currentTodo(newValue) {
      console.log(newValue);
      await localforage.setItem('todoapp-partialtodo', newValue);
      console.log("Todo memorizzato");
    }
  },
  async created() {
    console.log("The instance was created!")
    const prevTodo = await localforage.getItem('todoapp-partialtodo') || '';
    console.log(prevTodo);
    this.currentTodo = prevTodo;
  },
  mounted() {
    console.log("The instance was inserted into the DOM!")
  },
  updated() {
    console.log("The instance was updated!")
  },
  template: `
    <section class="todoapp">
        <header class="header">
            <todos-title :title="title"></todos-title>
            <!-- <input
              v-model.trim="currentTodo"
              @keyup.enter="handleKeyup"
              id="input-todo"
              class="new-todo"
              autofocus
              autocomplete="off"
              placeholder="What needs to be done?"> -->
            <todo-input v-model="currentTodo" @keyup="handleKeyup"></todo-input>
        </header>
        <section class="main">
          <todos-list
            :todos="todos"
            :completed-todos="completedTodos"
            @delete-todo="deleteTodo"
            @complete-todo="handleCompleteTodo"
          >
            <span>Nada</span>
          </todos-list>
            <!-- <ul class="todo-list">
                <li class="todo" v-if="isTodosEmpty">
                    <div class="view">
                        <label>Nothing to show here</label>
                    </div>
                </li>
                <template v-else>
                  <li
                  v-for="({title}, i) in todos"
                  class="todo"
                  :class="{completed: completedTodos.includes(i)}"
                  :key="i">
                      <div class="view">
                          <input class="toggle" v-model="completedTodos" :value="i"
                          type="checkbox">
                          <label>{{title}}</label>
                          <button class="destroy" @click="deleteTodo(i)"></button>
                      </div>
                  </li>
                </template>
            </ul> -->
        </section>
    </section>
  `
});