const vm = new Vue({
  el: '#app',
  data: {
    autocomplete: "off",
    disabled:true,
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    }],
  },
  methods: {
    handleEvent(event) {
      console.log(event.target.value);
      this.autocomplete = this.autocomplete === "off" ? "on" : "off";
    }
  },
  created() {
    console.log("The instance was created!")
  },
  mounted() {
    console.log("The instance was inserted into the DOM!")
  },
  updated() {
    console.log("The instance was updated!")
  },
  template: `
    <section class="todoapp">
        <header class="header">
            <h1>todos</h1>
            <input
              @input="handleEvent"
              class="new-todo"
              autofocus
              :autocomplete="autocomplete"
              :disabled="false"
              :placeholder="(() => 'Placeholder')()">
        </header>
        <section class="main">
            <ul class="todo-list">
                <li class="todo">
                    <div class="view">
                        <input class="toggle" type="checkbox">
                        <label>{{todos[0].title}}</label>
                        <button class="destroy"></button>
                    </div>
                </li>
                <li class="todo">
                    <div class="view">
                        <input class="toggle" type="checkbox">
                        <label>{{todos[1].title}}</label>
                        <button class="destroy"></button>
                    </div>
                </li>
                <li class="todo">
                    <div class="view">
                        <input class="toggle" type="checkbox">
                        <label>{{todos[2].title}}</label>
                        <button class="destroy"></button>
                    </div>
                </li>
            </ul>
        </section>
    </section>
  `
});