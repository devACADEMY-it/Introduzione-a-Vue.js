const vm = new Vue({
  el: '#app',
  data: {
    bgABCDEF: 'backgroundABCDEF',
    c000: 'color000',
    bool: true,
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    }],
  },
  methods: {
    handleEvent(event) {
      console.log(event.target.value);
    }
  },
  created() {
    console.log("The instance was created!")
  },
  mounted() {
    console.log("The instance was inserted into the DOM!")
  },
  updated() {
    console.log("The instance was updated!")
  },
  template: `
    <section class="todoapp">
        <header class="header">
            <h1>todos</h1>
            <input
              @input="handleEvent"
              class="new-todo"
              :class="{[bgABCDEF]: true, [c000]: bool}"
              autofocus
              :autocomplete="off"
              placeholder="What needs to be done?">
        </header>
        <section class="main">
            <ul class="todo-list">
                <li class="todo">
                    <div class="view">
                        <input class="toggle" type="checkbox">
                        <label>{{todos[0].title}}</label>
                        <button class="destroy"></button>
                    </div>
                </li>
                <li class="todo">
                    <div class="view">
                        <input class="toggle" type="checkbox">
                        <label>{{todos[1].title}}</label>
                        <button class="destroy"></button>
                    </div>
                </li>
                <li class="todo">
                    <div class="view">
                        <input class="toggle" type="checkbox">
                        <label>{{todos[2].title}}</label>
                        <button class="destroy"></button>
                    </div>
                </li>
            </ul>
        </section>
    </section>
  `
});