new Vue({
  el: '.todoapp',
  data: {
    todos: [{
      title:"Shopping!"
    },{
      title:"Video Corso"
    },{
      title:"Lavare i piatti"
    }],
  },
  methods: {
    allOk() {
      console.log("It's all ok!");
    },
    handleEvent(event) {
      this.allOk();
    }
  }
});